def alberti_encrypt(plaintext, outer_disk="ABCDEFGHIJKLMNOPQRSTUVWXYZ", inner_disk="XYZABCDEFGHIJKLMNOPQRSTUVW", period=3):
    """
    Chiffrement Alberti : le disque mobile tourne toutes les `period` lettres.
    """
    plaintext = plaintext.upper()
    ciphertext = ""
    rotation = 0
    for i, char in enumerate(plaintext):
        if char in outer_disk:
            idx = outer_disk.index(char)
            shifted_inner = inner_disk[rotation:] + inner_disk[:rotation]
            ciphertext += shifted_inner[idx]
            if (i + 1) % period == 0:
                rotation = (rotation + 1) % 26  # rotation du disque mobile
        else:
            ciphertext += char
    return ciphertext

def alberti_decrypt(ciphertext, outer_disk="ABCDEFGHIJKLMNOPQRSTUVWXYZ", inner_disk="XYZABCDEFGHIJKLMNOPQRSTUVW", period=3):
    """
    Déchiffrement Alberti : reproduit les rotations pour retrouver les correspondances.
    """
    ciphertext = ciphertext.upper()
    plaintext = ""
    rotation = 0
    for i, char in enumerate(ciphertext):
        shifted_inner = inner_disk[rotation:] + inner_disk[:rotation]
        if char in shifted_inner:
            idx = shifted_inner.index(char)
            plaintext += outer_disk[idx]
            if (i + 1) % period == 0:
                rotation = (rotation + 1) % 26
        else:
            plaintext += char
    return plaintext

# === Exemple d'utilisation ===
message = "Salem M1RSD"
cle_externe = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
cle_interne = "XYZABCDEFGHIJKLMNOPQRSTUVW"  # Disque tourné initialement
periode = 4  # Le disque tourne toutes les 4 lettres

chiffre = alberti_encrypt(message, cle_externe, cle_interne, periode)
print("Texte chiffré :", chiffre)

dechiffre = alberti_decrypt(chiffre, cle_externe, cle_interne, periode)
print("Texte déchiffré :", dechiffre)
