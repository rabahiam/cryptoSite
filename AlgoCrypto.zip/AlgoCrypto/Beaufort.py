def beaufort_cipher(text, key):
    """
    Chiffrement et déchiffrement du chiffre de Beaufort (auto-réciproque)
    """
    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    text = text.upper()
    key = key.upper()
    result = ''
    key_index = 0

    for char in text:
        if char in alphabet:
            t_index = alphabet.index(char)
            k_index = alphabet.index(key[key_index % len(key)])
            c_index = (k_index - t_index) % 26
            result += alphabet[c_index]
            key_index += 1
        else:
            result += char  # conserve les espaces ou caractères spéciaux
    return result

# === Exemple d’utilisation ===
message = "SALEMMUNRSD"
cle = "RBH"

chiffre = beaufort_cipher(message, cle)
print("Texte chiffré :", chiffre)

dechiffre = beaufort_cipher(chiffre, cle)
print("Texte déchiffré :", dechiffre)
