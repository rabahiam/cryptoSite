def porta_cipher(text, key):
    """
    Chiffrement / déchiffrement du chiffre de Porta.
    Le même algorithme sert pour les deux.
    """
    text = text.upper()
    key = key.upper()

    alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'

    porta_table = {
        'A': ('NOPQRSTUVWXYZABCDEFGHIJKLM'),
        'B': ('NOPQRSTUVWXYZABCDEFGHIJKLM'),
        'C': ('OPQRSTUVWXYZNMABCDEFGHIJKL'),
        'D': ('OPQRSTUVWXYZNMABCDEFGHIJKL'),
        'E': ('PQRSTUVWXYZONMLABCDEFGHIJK'),
        'F': ('PQRSTUVWXYZONMLABCDEFGHIJK'),
        'G': ('QRSTUVWXYZPONMLKABCDEFGHIJ'),
        'H': ('QRSTUVWXYZPONMLKABCDEFGHIJ'),
        'I': ('RSTUVWXYZQPONMLKJABCDEFGHI'),
        'J': ('RSTUVWXYZQPONMLKJABCDEFGHI'),
        'K': ('STUVWXYZRQPONMLKJIABCDEFGH'),
        'L': ('STUVWXYZRQPONMLKJIABCDEFGH'),
        'M': ('TUVWXYZSRQPONMLKJIHABCDEFG'),
        'N': ('TUVWXYZSRQPONMLKJIHABCDEFG'),
        'O': ('UVWXYZTSRQPONMLKJIHGFABCDE'),
        'P': ('UVWXYZTSRQPONMLKJIHGFABCDE'),
        'Q': ('VWXYZUTSRQPONMLKJIHGFEABCD'),
        'R': ('VWXYZUTSRQPONMLKJIHGFEABCD'),
        'S': ('WXYZVUTSRQPONMLKJIHGFEDABC'),
        'T': ('WXYZVUTSRQPONMLKJIHGFEDABC'),
        'U': ('XYZWVUTSRQPONMLKJIHGFEDCBA'),
        'V': ('XYZWVUTSRQPONMLKJIHGFEDCBA'),
        'W': ('YZXYWVUTSRQPONMLKJIHGFEDCB'),
        'X': ('YZXYWVUTSRQPONMLKJIHGFEDCB'),
        'Y': ('ZYYXWVUTSRQPONMLKJIHGFEDCA'),
        'Z': ('ZYYXWVUTSRQPONMLKJIHGFEDCA')
    }

    result = ''
    key_index = 0

    for char in text:
        if char.isalpha():
            k = key[key_index % len(key)]
            disk = porta_table.get(k, alphabet)
            i = alphabet.index(char)
            result += disk[i]
            key_index += 1
        else:
            result += char

    return result

# === Exemple d’utilisation ===
message = "SALEMMUNRSD"
key = "RBH"

encrypted = porta_cipher(message, key)
print("Texte chiffré :", encrypted)

decrypted = porta_cipher(encrypted, key)  # même fonction
print("Texte déchiffré :", decrypted)
