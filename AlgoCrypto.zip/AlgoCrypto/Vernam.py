def vernam_encrypt_decrypt(text, key):
    """
    Chiffrement et déchiffrement Vernam (OTP) par XOR bit à bit.
    La clé doit être de la même longueur que le texte.
    """
    if len(key) != len(text):
        raise ValueError("La clé doit être de la même longueur que le texte.")

    result = ''
    for t_char, k_char in zip(text, key):
        xor_value = ord(t_char) ^ ord(k_char)
        result += chr(xor_value)
    return result

# === Exemple d'utilisation ===
message = "SALEMMUNRSD"
key =     "RABAHTAMINE"  # même longueur que message

# Chiffrement
chiffre = vernam_encrypt_decrypt(message, key)
print("Texte chiffré (brut) :", repr(chiffre))

# Déchiffrement (même fonction)
dechiffre = vernam_encrypt_decrypt(chiffre, key)
print("Texte déchiffré :", dechiffre)
