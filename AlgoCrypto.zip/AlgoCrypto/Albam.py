def albam_cipher(text):
    result = ''
    for char in text:
        if char.isalpha():
            if char.isupper():
                base = ord('A')
            else:
                base = ord('a')
            shifted = (ord(char) - base + 13) % 26
            result += chr(base + shifted)
        else:
            result += char
    return result

# Exemple d'utilisation
message = "Salem M1RSD"
encrypted = albam_cipher(message)
print("Texte chiffré:", encrypted)
decrypted = albam_cipher(encrypted)
print("Texte déchiffré:", decrypted)
