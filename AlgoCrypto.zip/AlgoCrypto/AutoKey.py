def autokey_encrypt(plaintext, key):
    key = key.upper()
    plaintext = plaintext.upper()
    key += plaintext
    key = key[:len(plaintext)]
    ciphertext = ''
    for p, k in zip(plaintext, key):
        if p.isalpha():
            c = chr(((ord(p) - 65 + ord(k) - 65) % 26) + 65)
            ciphertext += c
        else:
            ciphertext += p
    return ciphertext

def autokey_decrypt(ciphertext, key):
    key = key.upper()
    plaintext = ''
    for i in range(len(ciphertext)):
        if ciphertext[i].isalpha():
            k = key[i]
            p = chr(((ord(ciphertext[i]) - ord(k) + 26) % 26) + 65)
            plaintext += p
            key += p
        else:
            plaintext += ciphertext[i]
            key += ciphertext[i]
    return plaintext

# Exemple d'utilisation
message = "SALEMM1RSD"
key = "RBH"
encrypted = autokey_encrypt(message, key)
print("Texte chiffré:", encrypted)
decrypted = autokey_decrypt(encrypted, key)
print("Texte déchiffré:", decrypted)
