from Crypto.Cipher import DES
from Crypto.Util.Padding import pad, unpad
import base64

def des_encrypt(plain_text, key):
    """
    Chiffre un texte avec DES (ECB, 16 rounds).
    :param plain_text: Texte à chiffrer
    :param key: Clé de 8 caractères
    :return: Texte chiffré (base64)
    """
    if len(key) != 8:
        raise ValueError("La clé doit contenir exactement 8 caractères.")
    des = DES.new(key.encode('utf-8'), DES.MODE_ECB)
    padded_text = pad(plain_text.encode('utf-8'), DES.block_size)
    encrypted_bytes = des.encrypt(padded_text)
    encrypted_b64 = base64.b64encode(encrypted_bytes).decode('utf-8')
    return encrypted_b64

def des_decrypt(encrypted_b64, key):
    """
    Déchiffre un texte chiffré avec DES.
    :param encrypted_b64: Texte chiffré (base64)
    :param key: Clé de 8 caractères
    :return: Texte déchiffré
    """
    if len(key) != 8:
        raise ValueError("La clé doit contenir exactement 8 caractères.")
    des = DES.new(key.encode('utf-8'), DES.MODE_ECB)
    encrypted_bytes = base64.b64decode(encrypted_b64)
    decrypted_padded = des.decrypt(encrypted_bytes)
    decrypted = unpad(decrypted_padded, DES.block_size).decode('utf-8')
    return decrypted

# === Exemple d'utilisation ===

texte = "Salem"
cle = "m1rsdrbh"  # Clé de 8 caractères exactement

chiffre = des_encrypt(texte, cle)
print("Texte chiffré :", chiffre)

dechiffre = des_decrypt(chiffre, cle)
print("Texte déchiffré :", dechiffre)
