def generate_key(message, key):
    key = list(key)
    if len(message) == len(key):
        return "".join(key)
    else:
        for i in range(len(message) - len(key)):
            key.append(key[i % len(key)])
    return "".join(key)

def encrypt_vigenere(message, key):
    encrypted_text = []
    key = generate_key(message, key)
    for i in range(len(message)):
        char = message[i]
        if char.isupper():
            encrypted_char = chr((ord(char) + ord(key[i]) - 2 * ord('A')) % 26 + ord('A'))
        elif char.islower():
            encrypted_char = chr((ord(char) + ord(key[i]) - 2 * ord('a')) % 26 + ord('a'))
        else:
            encrypted_char = char
        encrypted_text.append(encrypted_char)
    return "".join(encrypted_text)

def decrypt_vigenere(cipher_text, key):
    decrypted_text = []
    key = generate_key(cipher_text, key)
    for i in range(len(cipher_text)):
        char = cipher_text[i]
        if char.isupper():
            decrypted_char = chr((ord(char) - ord(key[i]) + 26) % 26 + ord('A'))
        elif char.islower():
            decrypted_char = chr((ord(char) - ord(key[i]) + 26) % 26 + ord('a'))
        else:
            decrypted_char = char
        decrypted_text.append(decrypted_char)
    return "".join(decrypted_text)

# Exemple d'utilisation
message = "Salem M1RSD"
key = "rbh"
encrypted = encrypt_vigenere(message, key)
print("Texte chiffré:", encrypted)
decrypted = decrypt_vigenere(encrypted, key)
print("Texte déchiffré:", decrypted)
