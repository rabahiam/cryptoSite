def trithemius_encrypt(plaintext):
    """
    Chiffrement Trithemius classique : décalage progressif A, B, C...
    """
    result = ""
    for i, char in enumerate(plaintext.upper()):
        if char.isalpha():
            offset = i % 26  # décale à chaque lettre
            encrypted_char = chr((ord(char) - ord('A') + offset) % 26 + ord('A'))
            result += encrypted_char
        else:
            result += char
    return result


def trithemius_decrypt(ciphertext):
    """
    Déchiffrement Trithemius classique
    """
    result = ""
    for i, char in enumerate(ciphertext.upper()):
        if char.isalpha():
            offset = i % 26
            decrypted_char = chr((ord(char) - ord('A') - offset) % 26 + ord('A'))
            result += decrypted_char
        else:
            result += char
    return result

# === Exemple d’utilisation ===
texte = "SALEMMUNRSD"
chiffre = trithemius_encrypt(texte)
print("Texte chiffré :", chiffre)

dechiffre = trithemius_decrypt(chiffre)
print("Texte déchiffré :", dechiffre)
