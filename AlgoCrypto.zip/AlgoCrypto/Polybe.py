def polybe_encrypt(text):
    """
    Chiffrement avec le carré de Polybe (I/J combinés).
    """
    square = [['A', 'B', 'C', 'D', 'E'],
              ['F', 'G', 'H', 'I', 'K'],
              ['L', 'M', 'N', 'O', 'P'],
              ['Q', 'R', 'S', 'T', 'U'],
              ['V', 'W', 'X', 'Y', 'Z']]

    char_to_coords = {}
    for i in range(5):
        for j in range(5):
            char = square[i][j]
            char_to_coords[char] = f"{i+1}{j+1}"
    # Ajouter I/J comme équivalent
    char_to_coords['J'] = char_to_coords['I']

    text = text.upper().replace("J", "I")
    encrypted = ''
    for char in text:
        if char.isalpha():
            encrypted += char_to_coords[char]
        else:
            encrypted += char  # espaces, ponctuation non modifiés
    return encrypted


def polybe_decrypt(code):
    """
    Déchiffrement avec le carré de Polybe.
    """
    square = [['A', 'B', 'C', 'D', 'E'],
              ['F', 'G', 'H', 'I', 'K'],
              ['L', 'M', 'N', 'O', 'P'],
              ['Q', 'R', 'S', 'T', 'U'],
              ['V', 'W', 'X', 'Y', 'Z']]

    decrypted = ''
    i = 0
    while i < len(code):
        if code[i].isdigit() and i + 1 < len(code) and code[i+1].isdigit():
            row = int(code[i]) - 1
            col = int(code[i+1]) - 1
            if 0 <= row < 5 and 0 <= col < 5:
                decrypted += square[row][col]
            else:
                decrypted += '?'  # en cas de coordonnées invalides
            i += 2
        else:
            decrypted += code[i]
            i += 1
    return decrypted

# === Exemple d'utilisation ===
message = "SALEMMUNRSD"
chiffre = polybe_encrypt(message)
print("Texte chiffré :", chiffre)

dechiffre = polybe_decrypt(chiffre)
print("Texte déchiffré :", dechiffre)
