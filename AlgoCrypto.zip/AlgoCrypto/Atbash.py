def atbash_cipher(text):
    result = ''
    for char in text:
        if char.isupper():
            result += chr(65 + (25 - (ord(char) - 65)))
        elif char.islower():
            result += chr(97 + (25 - (ord(char) - 97)))
        else:
            result += char
    return result

# Exemple d'utilisation
message = "Salem M1RSD"
encrypted = atbash_cipher(message)
print("Texte chiffré:", encrypted)
decrypted = atbash_cipher(encrypted)
print("Texte déchiffré:", decrypted)
